
exports.REDIS_SECRET = 'Rx#z(ANYRyp9NjfLp62gsgVbF';
exports.REDIS_HOST = 'localhost';
exports.REDIS_PORT = 6379;
exports.REDIS_AUTH = 'dZGVorD42Up/HWDU2n>RsfcZN';
exports.FRONTEND_PORT = 4000;
exports.API_URL = 'http://localhost:3000' //'http://chiquis.asuscomm.com:52797'  ; // 
