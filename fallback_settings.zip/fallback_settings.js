
exports.REDIS_SECRET = 'Rx#z(ANYRyp9NjfLp62gsgVbF';
exports.REDIS_HOST = 'localhost';
exports.REDIS_PORT = 6379;
exports.REDIS_AUTH = '';
exports.FRONTEND_PORT = 4001;
exports.API_URL = 'http://localhost:4000';

