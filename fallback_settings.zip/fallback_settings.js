
exports.REDIS_SECRET = 'Rx#z(ANYRyp9NjfLp62gsgVbF';
exports.REDIS_HOST = 'localhost';
exports.REDIS_PORT = 6379;
exports.REDIS_AUTH = '';
exports.FRONTEND_PORT = 4000;
// ###!! You need to add the fallback API URL to server/utils/react_constants.js  !!###

